namespace Mirror.SimpleWeb
{
    public enum EventType
    {
        Connected,
        Data,
        Disconnected,
        Error
    }
}
