using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("kcp2k.Tests")]